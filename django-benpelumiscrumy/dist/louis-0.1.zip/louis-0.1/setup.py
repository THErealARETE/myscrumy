from setuptools import setup, find_packages
setup(
    name="louis",
    version="0.1",
    author = "benpelumiscrumy",
    author_email = "louis@linuxjobber.com",
    packages=find_packages(),
)

