from setuptools import setup, find_packages
setup(
    name="benpelumi",
    version="0.1",
    author = "benpelumiscrumy",
    author_email = "benpelumi@gmail.com",
    packages=find_packages(),
)

